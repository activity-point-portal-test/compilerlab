#include <stdio.h>
int main()
{
    int x, y, z;
    x = 10;
    y = x + 45;
    z = y + 4;
    printf("The value of z = %d", z);
    return 0;
}
