Take the output in such a way that no two vowel letters comes together.
Example: In 'virtual', 'ua' are together. But in 'oracle', all vowels are atleast one consonant apart.